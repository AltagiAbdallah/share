<?php
session_start();

// Important: All header() redirects and session checks must happen BEFORE any output,
// including the inclusion of 'includes/header.php'.

// If user is already logged in, redirect to dashboard
if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php"); // This is now safely at the top
    exit();
}

$pageTitle = "Register - Sharebite";
// Now include header.php, after potential redirects
include 'includes/header.php'; // [cite: image_3d8576.png]

// No changes needed below this point for this specific error.
// The form processing for registration itself happens in create_user.php (via form action)
// so there's no POST handling directly in register.php that would cause redirects.
?>

<section class="hero-background-form-page text-white py-16 px-8 flex-grow flex items-center justify-center">
    <div class="relative z-10 max-w-lg mx-auto text-center">
        <h1 class="text-5xl md:text-6xl font-extrabold mb-4 leading-tight">
            Join Our Community
        </h1>
        <p class="text-xl md:text-2xl opacity-90 mb-8">
            Create an account to start sharing or receiving food.
        </p>

        <div class="form-card bg-white p-8 rounded-xl shadow-lg w-full max-w-md mx-auto text-left text-gray-800">
            <h2 class="text-3xl font-bold mb-6 text-center text-gray-800">Create Your Sharebite Account</h2>

            <?php if (isset($_SESSION['success_message'])): ?>
                <div class="bg-emerald-100 border-l-4 border-emerald-500 text-emerald-700 p-4 mb-4 rounded-md" role="alert">
                    <p><?php echo htmlspecialchars($_SESSION['success_message']); ?></p>
                </div>
                <?php unset($_SESSION['success_message']); ?>
            <?php endif; ?>

            <?php if (isset($_SESSION['error_message'])): ?>
                <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4 rounded-md" role="alert">
                    <p><?php echo htmlspecialchars($_SESSION['error_message']); ?></p>
                </div>
                <?php unset($_SESSION['error_message']); ?>
            <?php endif; ?>

            <form action="create_user.php" method="POST" class="space-y-5">
                <div>
                    <label for="name" class="block text-gray-700 text-lg font-semibold mb-2">Full Name</label>
                    <input type="text" id="name" name="name" placeholder="John Doe" required
                           class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 text-lg">
                </div>
                <div>
                    <label for="email" class="block text-gray-700 text-lg font-semibold mb-2">Email Address</label>
                    <input type="email" id="email" name="email" placeholder="your.email@example.com" required
                           class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 text-lg">
                </div>
                <div>
                    <label for="password" class="block text-gray-700 text-lg font-semibold mb-2">Password</label>
                    <input type="password" id="password" name="password" placeholder="••••••••" required
                           class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 text-lg">
                </div>
                <div>
                    <label for="confirm_password" class="block text-gray-700 text-lg font-semibold mb-2">Confirm Password</label>
                    <input type="password" id="confirm_password" name="confirm_password" placeholder="••••••••" required
                           class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 text-lg">
                </div>
                <div>
                    <label for="user_type" class="block text-gray-700 text-lg font-semibold mb-2">I am a...</label>
                    <select id="user_type" name="user_type" required
                            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 text-lg bg-white">
                        <option value="">Select Account Type</option>
                        <option value="donor">Donor (I want to share food)</option>
                        <option value="receiver">Receiver (I need food)</option>
                    </select>
                </div>
                <button type="submit" class="w-full bg-emerald-600 text-white py-3 px-6 rounded-full text-xl font-semibold hover:bg-emerald-700 transition duration-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:ring-opacity-50">
                    Register
                </button>
            </form>

            <p class="text-center text-gray-600 mt-6">
                Already have an account? <a href="login.php" class="text-emerald-600 hover:underline font-semibold">Login Here</a>
            </p>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>