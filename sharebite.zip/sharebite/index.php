<?php
session_start(); // Start the session if not already started
$pageTitle = "Home - Sharebite"; // Set the page title
include 'includes/header.php'; // Include the header
?>

<section class="hero-background-index text-white py-20 px-8 text-center flex-grow">
    <div class="relative z-10 max-w-4xl mx-auto">
        <h1 class="text-6xl md:text-7xl font-extrabold mb-6 leading-tight">
            Share Food. Reduce Waste. Build Community.
        </h1>
        <p class="text-2xl md:text-3xl opacity-90 mb-10">
            Connecting surplus food with those in need, creating a sustainable and caring community.
        </p>
        <div class="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-6">
            <?php if (!isset($_SESSION['user_id'])): // Show these buttons if not logged in ?>
                <a href="register.php" class="bg-emerald-600 text-white px-10 py-4 rounded-full text-xl font-semibold hover:bg-emerald-700 transition duration-200 shadow-lg">
                    Join Sharebite Today
                </a>
                <a href="login.php" class="bg-white text-emerald-600 px-10 py-4 rounded-full text-xl font-semibold hover:bg-emerald-50 transition duration-200 shadow-lg">
                    Login
                </a>
            <?php else: // If logged in, show a different button ?>
                <a href="dashboard.php" class="bg-emerald-600 text-white px-10 py-4 rounded-full text-xl font-semibold hover:bg-emerald-700 transition duration-200 shadow-lg">
                    Go to Dashboard
                </a>
            <?php endif; ?>
        </div>
    </div>
</section>

<section class="py-16 bg-white px-8">
    <div class="container mx-auto text-center">
        <h2 class="text-5xl font-extrabold text-gray-800 mb-12">How It Works</h2>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-10">
            <div class="feature-card bg-emerald-50 p-8 rounded-xl shadow-md transform hover:scale-105 transition duration-300">
                <div class="text-emerald-600 mb-4">
                    <svg class="h-16 w-16 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c1.657 0 3 1.343 3 3v2a3 3 0 01-3 3 3 3 0 01-3-3v-2c0-1.657 1.343-3 3-3z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 18v2m0 3a1 1 0 110-2 1 1 0 010 2z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 10h10a2 2 0 012 2v2a2 2 0 01-2 2H7a2 2 0 01-2-2v-2a2 2 0 012-2z"></path></svg>
                </div>
                <h3 class="text-2xl font-bold text-gray-800 mb-4">Donate Food</h3>
                <p class="text-gray-600">Have surplus food? List your donations quickly and easily to help those in need and reduce waste.</p>
                <a href="donate.php" class="mt-4 inline-block text-emerald-600 font-semibold hover:underline">Learn More &raquo;</a>
            </div>
            <div class="feature-card bg-emerald-50 p-8 rounded-xl shadow-md transform hover:scale-105 transition duration-300">
                <div class="text-emerald-600 mb-4">
                    <svg class="h-16 w-16 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 13h6m-3-3v6m5 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
                </div>
                <h3 class="text-2xl font-bold text-gray-800 mb-4">Browse & Request</h3>
                <p class="text-gray-600">Looking for food? Browse available donations in your area and send a request directly to donors.</p>
                <a href="browse.php" class="mt-4 inline-block text-emerald-600 font-semibold hover:underline">Start Browse &raquo;</a>
            </div>
            <div class="feature-card bg-emerald-50 p-8 rounded-xl shadow-md transform hover:scale-105 transition duration-300">
                <div class="text-emerald-600 mb-4">
                    <svg class="h-16 w-16 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H2v-2a3 3 0 015.356-1.857M9 20h2v-2a3 3 0 00-5.356-1.857M12 12a3 3 0 100-6 3 3 0 000 6zm-5.657-2.857a3 3 0 11-1.89-1.89C6.01 7.029 6.91 6 8 6h.057a3 3 0 01-.087-.514L7 3"></path></svg>
                </div>
                <h3 class="text-2xl font-bold text-gray-800 mb-4">Connect & Impact</h3>
                <p class="text-gray-600">Facilitate direct connections between donors and receivers, fostering a strong community impact.</p>
                <a href="about.php" class="mt-4 inline-block text-emerald-600 font-semibold hover:underline">About Sharebite &raquo;</a>
            </div>
        </div>
    </div>
</section>

<section class="bg-emerald-700 text-white py-16 px-8 text-center">
    <div class="container mx-auto max-w-3xl">
        <h2 class="text-4xl md:text-5xl font-extrabold mb-6">Make a Difference Today!</h2>
        <p class="text-lg md:text-xl mb-8 opacity-90">
            Join Sharebite and become part of a movement to fight food waste and hunger in your local area.
        </p>
        <div class="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-6">
            <?php if (!isset($_SESSION['user_id'])): ?>
                <a href="register.php" class="bg-white text-emerald-700 px-8 py-3 rounded-full text-lg font-semibold hover:bg-gray-100 transition duration-200 shadow-md">
                    Sign Up Now
                </a>
            <?php endif; ?>
            <a href="about.php" class="border border-white text-white px-8 py-3 rounded-full text-lg font-semibold hover:bg-white hover:text-emerald-700 transition duration-200 shadow-md">
                Learn More
            </a>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; // Include the footer ?>