<?php
session_start();
$pageTitle = "About Us - Sharebite";
include 'includes/header.php';
?>

<section class="hero-background-form-page text-white py-16 px-8 text-center">
    <div class="relative z-10 max-w-4xl mx-auto">
        <h1 class="text-5xl md:text-6xl font-extrabold mb-4 leading-tight">
            About Sharebite
        </h1>
        <p class="text-xl md:text-2xl opacity-90">
            Our mission to connect communities and reduce food waste.
        </p>
    </div>
</section>

<main class="flex-grow container mx-auto p-8">
    <div class="bg-white p-8 rounded-lg shadow-xl content-card">
        <h2 class="text-4xl font-extrabold text-gray-800 mb-8 text-center">Our Mission</h2>

        <p class="text-gray-700 text-lg leading-relaxed mb-6">
            Sharebite was founded on the simple yet powerful idea that no good food should go to waste when there are people in need. We are a community-driven platform dedicated to connecting individuals and businesses with surplus food to local receivers and organizations. Our goal is to reduce food waste, alleviate hunger, and foster a stronger, more sustainable community.
        </p>
        <p class="text-gray-700 text-lg leading-relaxed mb-6">
            We believe that by making it easy and efficient to share food, we can make a significant positive impact on both environmental sustainability and social well-being. Every donation, no matter how small, contributes to a larger movement of compassion and responsibility.
        </p>

        <h3 class="text-3xl font-bold text-gray-800 mb-6 mt-10 text-center">What We Do</h3>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-8 mb-10">
            <div class="bg-emerald-50 p-6 rounded-lg shadow-md border-t-4 border-emerald-500">
                <h4 class="text-xl font-semibold text-gray-800 mb-3">Facilitate Donations</h4>
                <p class="text-gray-600">
                    We provide an easy-to-use platform for donors to list their surplus food items, specifying details like quantity, pickup location, and any allergens.
                </p>
            </div>
            <div class="bg-emerald-50 p-6 rounded-lg shadow-md border-t-4 border-emerald-500">
                <h4 class="text-xl font-semibold text-gray-800 mb-3">Connect Receivers</h4>
                <p class="text-gray-600">
                    Individuals and organizations in need can browse available donations and submit requests directly through the platform.
                </p>
            </div>
            <div class="bg-emerald-50 p-6 rounded-lg shadow-md border-t-4 border-emerald-500">
                <h4 class="text-xl font-semibold text-gray-800 mb-3">Promote Sustainability</h4>
                <p class="text-gray-600">
                    By diverting edible food from landfills, we actively contribute to reducing greenhouse gas emissions and promoting a circular economy.
                </p>
            </div>
            <div class="bg-emerald-50 p-6 rounded-lg shadow-md border-t-4 border-emerald-500">
                <h4 class="text-xl font-semibold text-gray-800 mb-3">Build Community</h4>
                <p class="text-gray-600">
                    Sharebite fosters direct interactions and mutual support, strengthening local community bonds.
                </p>
            </div>
        </div>

        <h3 class="text-3xl font-bold text-gray-800 mb-6 mt-10 text-center">Our Vision</h3>
        <p class="text-gray-700 text-lg leading-relaxed mb-6">
            We envision a world where food waste is minimized, and everyone has access to nutritious food. Sharebite aims to be a leading platform in empowering communities to share resources efficiently and compassionately, creating a ripple effect of positive change.
        </p>

        <div class="text-center mt-10">
            <p class="text-gray-800 text-2xl font-semibold mb-4">Ready to make a difference?</p>
            <a href="register.php" class="bg-emerald-600 text-white px-8 py-3 rounded-full text-xl font-semibold hover:bg-emerald-700 transition duration-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:ring-opacity-50">
                Join Sharebite Today!
            </a>
        </div>
    </div>
</main>

<?php include 'includes/footer.php'; ?>