<?php
session_start();
include 'includes/db.php';

if (!isset($_SESSION['user_id'])) {
    $_SESSION['error_message'] = "You must be logged in to update your profile.";
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_SESSION['user_id'];
    $name = $_POST['name'];
    $email = $_POST['email'];

    if (empty($name) || empty($email)) {
        $_SESSION['error_message'] = "Name and email cannot be empty.";
        header("Location: profile.php");
        exit();
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['error_message'] = "Invalid email format.";
        header("Location: profile.php");
        exit();
    }

    // Check if new email already exists for another user
    $stmt_check_email = $conn->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
    $stmt_check_email->bind_param("si", $email, $user_id);
    $stmt_check_email->execute();
    $stmt_check_email->store_result();
    if ($stmt_check_email->num_rows > 0) {
        $_SESSION['error_message'] = "This email is already registered to another account.";
        $stmt_check_email->close();
        header("Location: profile.php");
        exit();
    }
    $stmt_check_email->close();

    $stmt = $conn->prepare("UPDATE users SET name = ?, email = ? WHERE id = ?");
    $stmt->bind_param("ssi", $name, $email, $user_id);

    if ($stmt->execute()) {
        // Update session variables if successful
        $_SESSION['name'] = $name;
        $_SESSION['email'] = $email;
        $_SESSION['success_message'] = "Profile updated successfully!";
    } else {
        $_SESSION['error_message'] = "Error updating profile: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
    header("Location: profile.php");
    exit();
} else {
    header("Location: profile.php");
    exit();
}
?>