<?php
session_start();
include 'includes/db.php'; // Ensure your database connection is included

if (!isset($_SESSION['user_id'])) {
    $_SESSION['error_message'] = "You must be logged in to access this page.";
    header("Location: login.php"); //
    exit();
}

$user_id = $_SESSION['user_id'];
$user_type = $_SESSION['user_type'];
$pageTitle = "My Contributions - Sharebite";
include 'includes/header.php'; //

$donations = [];
$requests = [];

// Fetch user's donations (if donor)
if ($user_type == 'donor') {
    // This query appears correct based on your donations table structure
    $stmt = $conn->prepare("SELECT d.id, d.food_item, d.quantity, d.status, d.created_at, c.name AS category_name FROM donations d LEFT JOIN categories c ON d.category_id = c.id WHERE d.user_id = ? ORDER BY d.created_at DESC");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $donations[] = $row;
    }
    $stmt->close();
}

// Fetch user's requests (if receiver)
if ($user_type == 'receiver') {
    // FIXES:
    // 1. Changed 'r.requested_at' to 'r.created_at' (assuming 'requests' table has a 'created_at' column).
    //    If your 'requests' table doesn't have 'created_at', you'll need to check its structure
    //    or remove the timestamp from this query and display.
    // 2. Changed 'd.pickup_location' to 'd.location' based on 'donations' table structure.
    // 3. Removed 'd.contact_info' as it does not exist in 'donations' table.
    $stmt = $conn->prepare("
        SELECT r.id AS request_id, r.status AS request_status, r.created_at,
               d.id AS donation_id, d.food_item, d.quantity, d.location,
               u.name AS donor_name, c.name AS category_name
        FROM requests r
        JOIN donations d ON r.donation_id = d.id
        JOIN users u ON d.user_id = u.id
        LEFT JOIN categories c ON d.category_id = c.id
        WHERE r.user_id = ?
        ORDER BY r.created_at DESC
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $requests[] = $row;
    }
    $stmt->close();
}
?>

<section class="hero-background-inner-page text-white py-16 px-8 text-center">
    <div class="relative z-10 max-w-3xl mx-auto">
        <h1 class="text-5xl md:text-6xl font-extrabold mb-4 leading-tight">
            My Contributions
        </h1>
        <p class="text-xl md:text-2xl opacity-90">
            View the status of your food donations and requests.
        </p>
    </div>
</section>

<main class="flex-grow container mx-auto p-8">
    <div class="bg-white p-8 rounded-lg shadow-xl content-card">
        <h2 class="text-4xl font-extrabold text-gray-800 mb-8 text-center">Your Activity</h2>

        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="bg-emerald-100 border-l-4 border-emerald-500 text-emerald-700 p-4 mb-6 rounded-md" role="alert">
                <p><?php echo htmlspecialchars($_SESSION['success_message']); ?></p>
            </div>
            <?php unset($_SESSION['success_message']); ?>
        <?php endif; ?>
        <?php if (isset($_SESSION['error_message'])): ?>
            <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6 rounded-md" role="alert">
                <p><?php echo htmlspecialchars($_SESSION['error_message']); ?></p>
            </div>
            <?php unset($_SESSION['error_message']); ?>
        <?php endif; ?>

        <?php if ($user_type == 'donor'): ?>
            <h3 class="text-3xl font-bold text-gray-800 mb-6 border-b pb-3">My Donations</h3>
            <?php if (!empty($donations)): ?>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
                    <?php foreach ($donations as $donation): ?>
                        <div class="bg-emerald-50 p-6 rounded-lg shadow-md border-t-4 border-emerald-600 flex flex-col justify-between">
                            <div>
                                <h4 class="text-2xl font-semibold text-gray-800 mb-2"><?php echo htmlspecialchars($donation['food_item']); ?></h4>
                                <p class="text-gray-700 mb-1">Quantity: <?php echo htmlspecialchars($donation['quantity']); ?></p>
                                <?php if (!empty($donation['category_name'])): ?>
                                    <p class="text-gray-700 mb-1">Category: <?php echo htmlspecialchars($donation['category_name']); ?></p>
                                <?php endif; ?>
                                <p class="text-gray-700 mb-1">Status: <span class="font-bold <?php echo ($donation['status'] == 'pending' ? 'text-blue-600' : ($donation['status'] == 'claimed' ? 'text-green-600' : 'text-red-600')); ?>"><?php echo ucfirst(htmlspecialchars($donation['status'])); ?></span></p>
                                <p class="text-gray-500 text-sm mt-2">Listed on: <?php echo date('M d, Y', strtotime($donation['created_at'])); ?></p>
                            </div>
                            <div class="mt-4 flex flex-col space-y-2">
                                <?php if ($donation['status'] == 'pending'): ?>
                                    <a href="edit_donation.php?id=<?php echo $donation['id']; ?>" class="bg-yellow-500 text-white px-4 py-2 rounded-full hover:bg-yellow-600 transition duration-200 text-center text-sm">Edit</a>
                                    <a href="cancel_donation.php?id=<?php echo $donation['id']; ?>" class="bg-red-500 text-white px-4 py-2 rounded-full hover:bg-red-600 transition duration-200 text-center text-sm" onclick="return confirm('Are you sure you want to cancel this donation?');">Cancel</a>
                                <?php elseif ($donation['status'] == 'claimed'): ?>
                                    <span class="text-center text-green-700 font-semibold text-sm">Claimed!</span>
                                    <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="bg-yellow-50 border-l-4 border-yellow-500 text-yellow-800 p-6 rounded-md mb-12" role="alert">
                    <p class="font-bold text-lg mb-2">No Donations Made Yet!</p>
                    <p class="text-md">You haven't made any food donations yet. <a href="donate.php" class="text-yellow-700 hover:underline font-semibold">Donate food now!</a></p>
                </div>
            <?php endif; ?>
        <?php endif; ?>

        <?php if ($user_type == 'receiver'): ?>
            <h3 class="text-3xl font-bold text-gray-800 mb-6 border-b pb-3">My Requests</h3>
            <?php if (!empty($requests)): ?>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <?php foreach ($requests as $request): ?>
                        <div class="bg-blue-50 p-6 rounded-lg shadow-md border-t-4 border-blue-600 flex flex-col justify-between">
                            <div>
                                <h4 class="text-2xl font-semibold text-gray-800 mb-2">Request for: <?php echo htmlspecialchars($request['food_item']); ?></h4>
                                <p class="text-gray-700 mb-1">Quantity: <?php echo htmlspecialchars($request['quantity']); ?></p>
                                <?php if (!empty($request['category_name'])): ?>
                                    <p class="text-gray-700 mb-1">Category: <?php echo htmlspecialchars($request['category_name']); ?></p>
                                <?php endif; ?>
                                <p class="text-gray-700 mb-1">From: <?php echo htmlspecialchars($request['donor_name']); ?></p>
                                <p class="text-gray-700 mb-1">Pickup: <?php echo htmlspecialchars($request['location']); ?></p> <p class="text-gray-700 mb-1">Request Status: <span class="font-bold <?php echo ($request['request_status'] == 'pending' ? 'text-blue-600' : ($request['request_status'] == 'accepted' ? 'text-green-600' : 'text-red-600')); ?>"><?php echo ucfirst(htmlspecialchars($request['request_status'])); ?></span></p>
                                <?php /* Removed contact_info display as the column isn't in donations table
                                <?php if ($request['request_status'] == 'accepted'): ?>
                                    <p class="text-green-700 mt-2"><strong>Donor Contact:</strong> <?php echo htmlspecialchars($request['donor_contact']); ?></p>
                                <?php endif; ?>
                                */ ?>
                                <p class="text-gray-500 text-sm mt-2">Requested on: <?php echo date('M d, Y', strtotime($request['created_at'])); ?></p> </div>
                            <div class="mt-4 flex flex-col space-y-2">
                                <?php if ($request['request_status'] == 'pending'): ?>
                                    <a href="cancel_request.php?id=<?php echo $request['request_id']; ?>" class="bg-red-500 text-white px-4 py-2 rounded-full hover:bg-red-600 transition duration-200 text-center text-sm" onclick="return confirm('Are you sure you want to cancel this request?');">Cancel Request</a>
                                <?php elseif ($request['request_status'] == 'accepted'): ?>
                                    <span class="text-center text-green-700 font-semibold text-sm">Your request has been accepted! Please coordinate pickup.</span>
                                <?php elseif ($request['request_status'] == 'declined'): ?>
                                    <span class="text-center text-red-700 font-semibold text-sm">Your request was declined.</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="bg-blue-50 border-l-4 border-blue-500 text-blue-800 p-6 rounded-md" role="alert">
                    <p class="font-bold text-lg mb-2">No Requests Made Yet!</p>
                    <p class="text-md">You haven't requested any food yet. <a href="browse.php" class="text-blue-700 hover:underline font-semibold">Browse available food now!</a></p>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</main>

<?php include 'includes/footer.php'; ?>