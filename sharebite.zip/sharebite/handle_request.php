<?php
session_start();
include 'includes/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'donor') {
    $_SESSION['error_message'] = "You must be logged in as a donor to handle requests.";
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $request_id = isset($_POST['request_id']) ? intval($_POST['request_id']) : 0;
    $action = $_POST['action'] ?? ''; // 'accept' or 'decline'
    $donor_id = $_SESSION['user_id'];

    if ($request_id <= 0 || !in_array($action, ['accept', 'decline'])) {
        $_SESSION['error_message'] = "Invalid request or action.";
        header("Location: dashboard.php"); // Or wherever donor views requests
        exit();
    }

    // First, verify that this request belongs to one of the donor's pending donations
    $stmt_verify = $conn->prepare("
        SELECT r.status, d.id AS donation_id, d.food_item
        FROM requests r
        JOIN donations d ON r.donation_id = d.id
        WHERE r.id = ? AND d.user_id = ? AND r.status = 'pending'
    ");
    $stmt_verify->bind_param("ii", $request_id, $donor_id);
    $stmt_verify->execute();
    $result_verify = $stmt_verify->get_result();
    $request_details = $result_verify->fetch_assoc();
    $stmt_verify->close();

    if (!$request_details) {
        $_SESSION['error_message'] = "Request not found, already processed, or you don't own the donation.";
        header("Location: dashboard.php"); // Or where donor views requests
        exit();
    }

    $donation_id = $request_details['donation_id'];
    $food_item = $request_details['food_item'];

    if ($action == 'accept') {
        // 1. Update the request status to 'accepted'
        $stmt_update_request = $conn->prepare("UPDATE requests SET status = 'accepted' WHERE id = ?");
        $stmt_update_request->bind_param("i", $request_id);
        $request_updated = $stmt_update_request->execute();
        $stmt_update_request->close();

        // 2. Update the donation status to 'claimed'
        $stmt_update_donation = $conn->prepare("UPDATE donations SET status = 'claimed' WHERE id = ?");
        $stmt_update_donation->bind_param("i", $donation_id);
        $donation_updated = $stmt_update_donation->execute();
        $stmt_update_donation->close();

        // 3. Decline all other pending requests for this specific donation
        $stmt_decline_others = $conn->prepare("UPDATE requests SET status = 'declined' WHERE donation_id = ? AND id != ? AND status = 'pending'");
        $stmt_decline_others->bind_param("ii", $donation_id, $request_id);
        $stmt_decline_others->execute();
        $stmt_decline_others->close();


        if ($request_updated && $donation_updated) {
            $_SESSION['success_message'] = "Request for '" . htmlspecialchars($food_item) . "' accepted! Donation claimed.";
        } else {
            $_SESSION['error_message'] = "Failed to accept request for '" . htmlspecialchars($food_item) . "'.";
        }

    } elseif ($action == 'decline') {
        // Update the request status to 'declined'
        $stmt_update = $conn->prepare("UPDATE requests SET status = 'declined' WHERE id = ?");
        $stmt_update->bind_param("i", $request_id);

        if ($stmt_update->execute()) {
            $_SESSION['success_message'] = "Request for '" . htmlspecialchars($food_item) . "' declined.";
        } else {
            $_SESSION['error_message'] = "Failed to decline request for '" . htmlspecialchars($food_item) . "'.";
        }
        $stmt_update->close();
    }

    $conn->close();
    header("Location: my_contributions.php"); // Redirect back to my_contributions or a specific "view requests" page for the donor
    exit();

} else {
    header("Location: dashboard.php"); // Redirect if not a POST request
    exit();
}
?>