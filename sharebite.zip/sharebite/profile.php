<?php
session_start();
include 'includes/db.php';

if (!isset($_SESSION['user_id'])) {
    $_SESSION['error_message'] = "You must be logged in to access this page.";
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$pageTitle = "My Profile - Sharebite";
include 'includes/header.php';

$user_data = null;
$stmt = $conn->prepare("SELECT name, email, user_type FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows > 0) {
    $user_data = $result->fetch_assoc();
}
$stmt->close();

if (!$user_data) {
    $_SESSION['error_message'] = "User data not found. Please try logging in again.";
    header("Location: logout.php"); // Log out if user data can't be fetched
    exit();
}
?>

<section class="hero-background-form-page text-white py-16 px-8 text-center">
    <div class="relative z-10 max-w-3xl mx-auto">
        <h1 class="text-5xl md:text-6xl font-extrabold mb-4 leading-tight">
            My Profile
        </h1>
        <p class="text-xl md:text-2xl opacity-90">
            View and update your account details.
        </p>
    </div>
</section>

<main class="flex-grow container mx-auto p-8">
    <div class="form-card bg-white p-8 rounded-lg shadow-lg w-full max-w-2xl mx-auto text-left text-gray-800">
        <h2 class="text-4xl font-extrabold text-gray-800 mb-8 text-center">Account Information</h2>

        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="bg-emerald-100 border-l-4 border-emerald-500 text-emerald-700 p-4 mb-6 rounded-md" role="alert">
                <p><?php echo htmlspecialchars($_SESSION['success_message']); ?></p>
            </div>
            <?php unset($_SESSION['success_message']); ?>
        <?php endif; ?>
        <?php if (isset($_SESSION['error_message'])): ?>
            <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6 rounded-md" role="alert">
                <p><?php echo htmlspecialchars($_SESSION['error_message']); ?></p>
            </div>
            <?php unset($_SESSION['error_message']); ?>
        <?php endif; ?>

        <form action="update_profile.php" method="POST" class="space-y-6">
            <div>
                <label for="name" class="block text-gray-700 text-lg font-semibold mb-2">Full Name</label>
                <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($user_data['name']); ?>" required
                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 text-lg">
            </div>

            <div>
                <label for="email" class="block text-gray-700 text-lg font-semibold mb-2">Email Address</label>
                <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($user_data['email']); ?>" required
                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 text-lg">
            </div>

            <div>
                <label for="user_type" class="block text-gray-700 text-lg font-semibold mb-2">Account Type</label>
                <input type="text" id="user_type" name="user_type" value="<?php echo ucfirst(htmlspecialchars($user_data['user_type'])); ?>" readonly
                       class="w-full px-4 py-3 border border-gray-300 rounded-lg bg-gray-100 cursor-not-allowed focus:outline-none text-lg">
                <p class="text-sm text-gray-500 mt-1">Contact support to change your account type.</p>
            </div>

            <button type="submit" class="w-full bg-emerald-600 text-white py-3 px-6 rounded-full text-xl font-semibold hover:bg-emerald-700 transition duration-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:ring-opacity-50">
                Update Profile
            </button>
        </form>

        <h3 class="text-3xl font-bold text-gray-800 mb-6 mt-12 text-center border-t pt-8">Change Password</h3>
        <form action="change_password.php" method="POST" class="space-y-6">
            <div>
                <label for="current_password" class="block text-gray-700 text-lg font-semibold mb-2">Current Password</label>
                <input type="password" id="current_password" name="current_password" placeholder="••••••••" required
                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 text-lg">
            </div>
            <div>
                <label for="new_password" class="block text-gray-700 text-lg font-semibold mb-2">New Password</label>
                <input type="password" id="new_password" name="new_password" placeholder="••••••••" required
                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 text-lg">
            </div>
            <div>
                <label for="confirm_new_password" class="block text-gray-700 text-lg font-semibold mb-2">Confirm New Password</label>
                <input type="password" id="confirm_new_password" name="confirm_new_password" placeholder="••••••••" required
                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 text-lg">
            </div>
            <button type="submit" class="w-full bg-purple-600 text-white py-3 px-6 rounded-full text-xl font-semibold hover:bg-purple-700 transition duration-200 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-opacity-50">
                Change Password
            </button>
        </form>
    </div>
</main>

<?php include 'includes/footer.php'; ?>