<?php
session_start();
include 'includes/db.php'; // Ensure this path is correct

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'receiver') {
    $_SESSION['error_message'] = "You must be logged in as a receiver to access this page.";
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$pageTitle = "Browse Donations - Sharebite";
include 'includes/header.php'; // Includes Tailwind CSS

// Add this line for debugging to confirm the file version being executed
error_log("DEBUG: browse.php - Running version 20250614-6"); // Updated debug version

// Fetch all available donations (status = 'available' - matching your ENUM type)
$donations = [];
$stmt = $conn->prepare("
    SELECT
        d.id,
        d.food_item,
        d.quantity,
        d.location,
        d.description,    -- Include description
        d.allergens,      -- Include allergens
        d.expiry_date,    -- Include expiry_date
        d.contact_info,   -- Include contact_info
        d.created_at,
        u.name AS donor_name,
        c.name AS category_name
    FROM
        donations d
    JOIN
        users u ON d.user_id = u.id
    LEFT JOIN
        categories c ON d.category_id = c.id
    WHERE
        d.status = 'available' -- Changed from 'pending' to 'available' to match your DB ENUM
    ORDER BY
        d.created_at DESC
");

if ($stmt === false) {
    // Handle prepare error, e.g., if columns still don't match or syntax error
    error_log("MySQL prepare error: " . $conn->error);
    $_SESSION['error_message'] = "Database query failed. Please try again later.";
    // Do NOT redirect here, as headers might already be sent if header.php outputs HTML.
    // Instead, just display the error on the current page.
    $donations = []; // Ensure donations array is empty to prevent further errors
} else {
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $donations[] = $row;
    }
    $stmt->close();
}

?>

<section class="hero-background-inner-page text-white py-16 px-8 text-center">
    <div class="relative z-10 max-w-3xl mx-auto">
        <h1 class="text-5xl md:text-6xl font-extrabold mb-4 leading-tight">
            Browse Available Food
        </h1>
        <p class="text-xl md:text-2xl opacity-90">
            Discover fresh food donations in your community and make a request.
        </p>
    </div>
</section>

<main class="flex-grow container mx-auto p-8">
    <div class="bg-white p-8 rounded-lg shadow-xl content-card">
        <h2 class="text-4xl font-extrabold text-gray-800 mb-8 text-center">Current Food Listings</h2>

        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="bg-emerald-100 border-l-4 border-emerald-500 text-emerald-700 p-4 mb-6 rounded-md" role="alert">
                <p><?php echo htmlspecialchars($_SESSION['success_message']); ?></p>
            </div>
            <?php unset($_SESSION['success_message']); ?>
        <?php endif; ?>
        <?php if (isset($_SESSION['error_message'])): ?>
            <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6 rounded-md" role="alert">
                <p><?php echo htmlspecialchars($_SESSION['error_message']); ?></p>
            </div>
            <?php unset($_SESSION['error_message']); ?>
        <?php endif; ?>

        <?php if (!empty($donations)): ?>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <?php foreach ($donations as $donation): ?>
                    <div class="bg-emerald-50 p-6 rounded-lg shadow-md border-t-8 border-emerald-500 flex flex-col justify-between hover:shadow-lg transition duration-200">
                        <div>
                            <h3 class="text-2xl font-bold text-gray-800 mb-3"><?php echo htmlspecialchars($donation['food_item']); ?></h3>
                            <p class="text-gray-700 mb-2"><strong>Quantity:</strong> <?php echo htmlspecialchars($donation['quantity']); ?></p>
                            <?php if (!empty($donation['category_name'])): ?>
                                <p class="text-gray-700 mb-2"><strong>Category:</strong> <?php echo htmlspecialchars($donation['category_name']); ?></p>
                            <?php endif; ?>
                            <p class="text-gray-700 mb-2"><strong>Donor:</strong> <?php echo htmlspecialchars($donation['donor_name']); ?></p>
                            <p class="text-gray-700 mb-2"><strong>Location:</strong> <?php echo htmlspecialchars($donation['location']); ?></p>
                            <?php if (!empty($donation['description'])): ?>
                                <p class="text-gray-600 text-sm mb-2"><em><?php echo htmlspecialchars($donation['description']); ?></em></p>
                            <?php endif; ?>
                            <?php if (!empty($donation['allergens'])): ?>
                                <p class="text-red-600 text-sm mb-2"><strong>Allergens:</strong> <?php echo htmlspecialchars($donation['allergens']); ?></p>
                            <?php endif; ?>
                            <?php if (!empty($donation['expiry_date'])): ?>
                                <p class="text-gray-500 text-sm mb-4">Expires: <?php echo date('M d, Y', strtotime($donation['expiry_date'])); ?></p>
                            <?php endif; ?>
                            <?php if (!empty($donation['contact_info'])): ?>
                                <p class="text-gray-700 mb-2"><strong>Contact Info:</strong> <?php echo htmlspecialchars($donation['contact_info']); ?></p>
                            <?php endif; ?>
                            <p class="text-gray-500 text-sm mt-2">Listed on: <?php echo date('M d, Y', strtotime($donation['created_at'])); ?></p>
                        </div>
                        <a href="request.php?donation_id=<?php echo $donation['id']; ?>" class="w-full text-center bg-emerald-600 text-white px-6 py-3 rounded-full text-lg font-semibold hover:bg-emerald-700 transition duration-200 block mt-4">
                            Request This Food &raquo;
                        </a>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="bg-lime-50 border-l-4 border-lime-500 text-lime-800 p-6 rounded-md" role="alert">
                <p class="font-bold text-lg mb-2">No Food Donations Available Right Now!</p>
                <p class="text-md">Please check back later, or contact us if you have urgent needs.</p>
            </div>
        <?php endif; ?>
    </div>
</main>

<?php include 'includes/footer.php'; ?>