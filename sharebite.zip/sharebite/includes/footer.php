<footer class="bg-gray-800 text-white p-6 text-center mt-auto">
        <div class="container mx-auto">
            <p>&copy; <?php echo date('Y'); ?> Sharebite. All rights reserved.</p>
            <p class="text-sm mt-2">Connecting communities, one meal at a time.</p>
            <div class="flex justify-center space-x-4 mt-4">
                <a href="#" class="text-gray-400 hover:text-emerald-400 transition duration-200">Privacy Policy</a>
                <a href="#" class="text-gray-400 hover:text-emerald-400 transition duration-200">Terms of Service</a>
                <a href="#" class="text-gray-400 hover:text-emerald-400 transition duration-200">Contact Us</a>
            </div>
        </div>
    </footer>

</body>
</html>