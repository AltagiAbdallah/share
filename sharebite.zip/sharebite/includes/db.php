<?php
// db.php - Database connection file

$servername = "localhost"; // Your database server name (usually 'localhost' for XAMPP)
$username = "root";        // Your database username (default for XAMPP is 'root')
$password = "";            // Your database password (default for XAMPP is empty)
$dbname = "sharebite";     // The name of your database (from your phpMyAdmin screenshots)

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    // For debugging, you can display the error, but in production, it's better to log it
    // and show a generic error message to the user.
    die("Connection failed: " . $conn->connect_error);
}

// Set charset to UTF-8 for proper character handling
$conn->set_charset("utf8mb4");

// Optional: You might not strictly need to close the connection here
// as it will be automatically closed when the script finishes execution.
// However, if you explicitly want to close it at specific points, you can use $conn->close();
?>