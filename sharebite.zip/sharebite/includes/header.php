<?php

session_start();

include 'includes/db.php'; // Ensure this path is correct



// --- IMPORTANT: ALL REDIRECTS AND DATA PROCESSING MUST OCCUR BEFORE ANY HTML OUTPUT ---



// 1. Check user session and type for access control

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'receiver') {

    $_SESSION['error_message'] = "You must be logged in as a receiver to request food.";

    header("Location: login.php");

    exit();

}



// 2. Validate donation ID from GET parameter

$donation_id = isset($_GET['donation_id']) ? intval($_GET['donation_id']) : 0;



if ($donation_id <= 0) {

    $_SESSION['error_message'] = "Invalid donation ID.";

    header("Location: browse.php");

    exit();

}



// 3. Fetch donation details

$donation = null;

// Ensure 'd.location' matches your database column name and 'd.status' is 'available'

$stmt = $conn->prepare("SELECT d.food_item, d.quantity, d.location, d.description, d.allergens, d.expiry_date, d.contact_info, u.name AS donor_name FROM donations d JOIN users u ON d.user_id = u.id WHERE d.id = ? AND d.status = 'available'");

$stmt->bind_param("i", $donation_id);

$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows > 0) {

    $donation = $result->fetch_assoc();

}

$stmt->close();



// 4. Check if donation exists and is available

if (!$donation) {

    $_SESSION['error_message'] = "Donation not found or no longer available.";

    header("Location: browse.php");

    exit();

}



$user_id = $_SESSION['user_id'];



// --- 5. Handle POST request for confirming the request (BEFORE any HTML output) ---

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Check if user has already requested this donation to prevent duplicates

    $stmt_check = $conn->prepare("SELECT id FROM requests WHERE user_id = ? AND donation_id = ?");

    $stmt_check->bind_param("ii", $user_id, $donation_id);

    $stmt_check->execute();

    $result_check = $stmt_check->get_result();



    if ($result_check->num_rows > 0) {

        // User has already sent a request for this donation

        $_SESSION['error_message'] = "You have already sent a request for this donation.";

        header("Location: my_contributions.php"); // Redirect to my_contributions

        exit(); // Crucial to exit after header redirect

    }

    $stmt_check->close();



    // Insert the new request into the database

    $stmt = $conn->prepare("INSERT INTO requests (user_id, donation_id, status) VALUES (?, ?, 'pending')");

    $stmt->bind_param("ii", $user_id, $donation_id);



    if ($stmt->execute()) {

        // Request successfully sent

        $_SESSION['success_message'] = "Your request for " . htmlspecialchars($donation['food_item']) . " has been sent successfully!";

        header("Location: my_contributions.php"); // Redirect to my_contributions to see the request

        exit(); // Crucial to exit after header redirect

    } else {

        // Error occurred during insertion

        $_SESSION['error_message'] = "Error sending request: " . $stmt->error;

        // No header() here; the page will fall through and display the error message below the form.

    }

    $stmt->close();

}



// --- END OF SERVER-SIDE LOGIC AND REDIRECTS ---



// --- START OF HTML OUTPUT ---

// Now, and ONLY now, if no redirect has happened, include the header and display the page content.

$pageTitle = "Request " . htmlspecialchars($donation['food_item']) . " - Sharebite";

include 'includes/header.php';

?>



<section class="hero-background-inner-page text-white py-16 px-8 text-center">

    <div class="relative z-10 max-w-3xl mx-auto">

        <h1 class="text-5xl md:text-6xl font-extrabold mb-4 leading-tight">

            Request Food Item

        </h1>

        <p class="text-xl md:text-2xl opacity-90">

            Confirm your request for <?php echo htmlspecialchars($donation['food_item']); ?>.

        </p>

    </div>

</section>



<main class="flex-grow container mx-auto p-8">

    <div class="form-card bg-white p-8 rounded-lg shadow-lg w-full max-w-xl mx-auto text-left text-gray-800">

        <h2 class="text-4xl font-extrabold text-gray-800 mb-8 text-center">Request Details</h2>



        <?php if (isset($_SESSION['success_message'])): ?>

            <div class="bg-emerald-100 border-l-4 border-emerald-500 text-emerald-700 p-4 mb-6 rounded-md" role="alert">

                <p><?php echo htmlspecialchars($_SESSION['success_message']); ?></p>

            </div>

            <?php unset($_SESSION['success_message']); ?>

        <?php endif; ?>

        <?php if (isset($_SESSION['error_message'])): ?>

            <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6 rounded-md" role="alert">

                <p><?php echo htmlspecialchars($_SESSION['error_message']); ?></p>

            </div>

            <?php unset($_SESSION['error_message']); ?>

        <?php endif; ?>



        <div class="space-y-4 text-lg">

            <p><strong>Food Item:</strong> <?php echo htmlspecialchars($donation['food_item']); ?></p>

            <p><strong>Quantity:</strong> <?php echo htmlspecialchars($donation['quantity']); ?></p>

            <p><strong>Donor:</strong> <?php echo htmlspecialchars($donation['donor_name']); ?></p>

            <p><strong>Pickup Location:</strong> <?php echo htmlspecialchars($donation['location']); ?></p>

            <?php if (!empty($donation['description'])): ?>

                <p><strong>Description:</strong> <em><?php echo htmlspecialchars($donation['description']); ?></em></p>

            <?php endif; ?>

            <?php if (!empty($donation['allergens'])): ?>

                <p class="text-red-600"><strong>Allergens:</strong> <?php echo htmlspecialchars($donation['allergens']); ?></p>

            <?php endif; ?>

            <p><strong>Expiry Date:</strong> <?php echo date('M d, Y', strtotime($donation['expiry_date'])); ?></p>

        </div>



        <p class="text-center text-gray-700 text-xl font-semibold mt-8 mb-6">

            Do you wish to proceed with requesting this food item?

        </p>



        <form action="request.php?donation_id=<?php echo $donation_id; ?>" method="POST">

            <button type="submit" class="w-full bg-blue-600 text-white py-3 px-6 rounded-full text-xl font-semibold hover:bg-blue-700 transition duration-200 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50">

                Confirm Request

            </button>

            <a href="browse.php" class="w-full block text-center mt-4 bg-gray-300 text-gray-800 py-3 px-6 rounded-full text-xl font-semibold hover:bg-gray-400 transition duration-200">

                Cancel

            </a>

        </form>

    </div>

</main>



<?php include 'includes/footer.php'; ?>