<?php
session_start(); // Ensure session is started at the very top
include 'includes/db.php'; // Ensure your database connection is included

if (!isset($_SESSION['user_id'])) {
    $_SESSION['error_message'] = "You must be logged in to access the dashboard.";
    header("Location: login.php"); //
    exit();
}

$user_id = $_SESSION['user_id'];
$user_type = $_SESSION['user_type'];
// FIX: Changed 'name' to 'user_name' to match what's set in login.php
$userName = htmlspecialchars($_SESSION['user_name']); // This is line 13 in your provided code

$pageTitle = "Dashboard - Sharebite";
include 'includes/header.php'; //
?>

<section class="hero-background-inner-page text-white py-16 px-8 text-center">
    <div class="relative z-10 max-w-3xl mx-auto">
        <h1 class="text-5xl md:text-6xl font-extrabold mb-4 leading-tight">
            Hello, <?php echo $userName; ?>!
        </h1>
        <p class="text-xl md:text-2xl opacity-90">
            Explore the features of Sharebite and manage your contributions.
        </p>
    </div>
</section>

<main class="flex-grow container mx-auto p-8">
    <div class="bg-white p-8 rounded-lg shadow-xl content-card">
        <h2 class="text-4xl font-extrabold text-gray-800 mb-8 text-center">Your Dashboard</h2>

        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="bg-emerald-100 border-l-4 border-emerald-500 text-emerald-700 p-4 mb-6 rounded-md" role="alert">
                <p><?php echo htmlspecialchars($_SESSION['success_message']); ?></p>
            </div>
            <?php unset($_SESSION['success_message']); ?>
        <?php endif; ?>
        <?php if (isset($_SESSION['error_message'])): ?>
            <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6 rounded-md" role="alert">
                <p><?php echo htmlspecialchars($_SESSION['error_message']); ?></p>
            </div>
            <?php unset($_SESSION['error_message']); ?>
        <?php endif; ?>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
            <?php if ($user_type == 'donor'): ?>
                <div class="dashboard-card bg-emerald-50 p-6 rounded-lg shadow-md border-t-8 border-emerald-500 flex flex-col justify-between">
                    <div>
                        <h3 class="text-2xl font-bold text-gray-800 mb-3">Offer Food Donation</h3>
                        <p class="text-gray-600 mb-4">Ready to share? Post details about the food you want to donate and help those in need.</p>
                    </div>
                    <a href="donate.php" class="bg-emerald-600 text-white px-6 py-3 rounded-full text-lg font-semibold hover:bg-emerald-700 transition duration-200 text-center block mt-4">
                        Donate Now &raquo;
                    </a>
                </div>
            <?php elseif ($user_type == 'receiver'): ?>
                <div class="dashboard-card bg-blue-50 p-6 rounded-lg shadow-md border-t-8 border-blue-500 flex flex-col justify-between">
                    <div>
                        <h3 class="text-2xl font-bold text-gray-800 mb-3">Find Available Food</h3>
                        <p class="text-gray-600 mb-4">Browse through current food donations in your area and request what you need.</p>
                    </div>
                    <a href="browse.php" class="bg-blue-600 text-white px-6 py-3 rounded-full text-lg font-semibold hover:bg-blue-700 transition duration-200 text-center block mt-4">
                        Browse Food &raquo;
                    </a>
                </div>
            <?php endif; ?>

            <div class="dashboard-card bg-purple-50 p-6 rounded-lg shadow-md border-t-8 border-purple-500 flex flex-col justify-between">
                <div>
                    <h3 class="text-2xl font-bold text-gray-800 mb-3">My Contributions</h3>
                    <p class="text-gray-600 mb-4">View and manage your past donations or requests. Track their status.</p>
                </div>
                <a href="my_contributions.php" class="bg-purple-600 text-white px-6 py-3 rounded-full text-lg font-semibold hover:bg-purple-700 transition duration-200 text-center block mt-4">
                    View History &raquo;
                </a>
            </div>

            <div class="dashboard-card bg-yellow-50 p-6 rounded-lg shadow-md border-t-8 border-yellow-500 flex flex-col justify-between">
                <div>
                    <h3 class="text-2xl font-bold text-gray-800 mb-3">Profile & Settings</h3>
                    <p class="text-gray-600 mb-4">Update your personal information, password, and preferences.</p>
                </div>
                <a href="profile.php" class="bg-yellow-600 text-white px-6 py-3 rounded-full text-lg font-semibold hover:bg-yellow-700 transition duration-200 text-center block mt-4">
                    Edit Profile &raquo;
                </a>
            </div>
        </div>
    </div>
</main>

<?php include 'includes/footer.php'; ?>