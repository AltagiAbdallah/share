<?php
session_start();
include 'includes/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'receiver') {
    $_SESSION['error_message'] = "You must be logged in as a receiver to cancel requests.";
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$request_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($request_id <= 0) {
    $_SESSION['error_message'] = "Invalid request ID.";
    header("Location: my_contributions.php");
    exit();
}

// Check if the request belongs to the logged-in user and is still 'pending'
$stmt = $conn->prepare("SELECT id, donation_id FROM requests WHERE id = ? AND user_id = ? AND status = 'pending'");
$stmt->bind_param("ii", $request_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();
$request_data = $result->fetch_assoc();
$stmt->close();

if ($request_data) {
    // Request exists and is pending, proceed to cancel
    $stmt_update = $conn->prepare("UPDATE requests SET status = 'cancelled' WHERE id = ?");
    $stmt_update->bind_param("i", $request_id);

    if ($stmt_update->execute()) {
        $_SESSION['success_message'] = "Request cancelled successfully.";
    } else {
        $_SESSION['error_message'] = "Error cancelling request: " . $stmt_update->error;
    }
    $stmt_update->close();
} else {
    $_SESSION['error_message'] = "Request not found, already processed, or you do not have permission.";
}

$conn->close();
header("Location: my_contributions.php");
exit();
?>