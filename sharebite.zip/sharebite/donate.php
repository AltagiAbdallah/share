<?php
session_start();
include 'includes/db.php';

// ALL form processing and redirects MUST happen BEFORE any HTML output.
// This means before 'include 'includes/header.php';' and before any direct HTML.

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'donor') {
    $_SESSION['error_message'] = "You must be logged in as a donor to access this page.";
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_SESSION['user_id']; // Get user_id here as well, if needed for error redirects
    $food_item = $_POST['food_item'];
    $category_id = $_POST['category_id'];
    $quantity = $_POST['quantity'];
    $pickup_location = $_POST['pickup_location'];
    $description = $_POST['description'] ?? '';
    $allergens = $_POST['allergens'] ?? '';
    $expiry_date = $_POST['expiry_date'];
    $contact_info = $_POST['contact_info'];

    // Basic validation
    if (empty($food_item) || empty($quantity) || empty($pickup_location) || empty($expiry_date) || empty($contact_info) || empty($category_id)) {
        $_SESSION['error_message'] = "Please fill in all required fields.";
        header("Location: donate.php"); // Redirect back on validation error
        exit();
    } else {
        // Handle image upload
        // IMPORTANT: Change 'uploads/' to 'images/' if you intend to use the 'images' folder.
        $target_dir = "images/"; // Corrected based on our previous discussion
        if (!is_dir($target_dir)) {
            mkdir($target_dir, 0777, true);
        }
        $image_name = '';
        if (isset($_FILES["image"]) && $_FILES["image"]["error"] == 0) {
            $image_file_type = strtolower(pathinfo($_FILES["image"]["name"], PATHINFO_EXTENSION));
            $allowed_types = array("jpg", "png", "jpeg", "gif");
            if (in_array($image_file_type, $allowed_types)) {
                $image_name = uniqid() . "." . $image_file_type;
                $target_file = $target_dir . $image_name;
                if (!move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
                    $_SESSION['error_message'] = "Sorry, there was an error uploading your image.";
                    $image_name = ''; // Reset image name if upload fails
                    header("Location: donate.php"); // Redirect back on image upload error
                    exit();
                }
            } else {
                $_SESSION['error_message'] = "Only JPG, JPEG, PNG & GIF files are allowed for images.";
                header("Location: donate.php"); // Redirect back on invalid image type
                exit();
            }
        }

        // Proceed only if no image upload error (and no initial validation error, handled by earlier redirect)
        // Note: The previous logic of `!isset($_SESSION['error_message'])` might be redundant
        // if you exit immediately after setting the error message.
        // It's safer to check for errors directly before the DB insert.
        if (empty($_SESSION['error_message'])) { // Check if no error message was set above
            $status = 'pending'; // Initial status for a new donation

            $stmt = $conn->prepare("INSERT INTO donations (user_id, category_id, food_item, image, quantity, location, description, allergens, expiry_date, contact_info, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("iisssssssss", $user_id, $category_id, $food_item, $image_name, $quantity, $pickup_location, $description, $allergens, $expiry_date, $contact_info, $status);

            if ($stmt->execute()) {
                $_SESSION['success_message'] = "Your food donation has been listed successfully!";
                header("Location: my_contributions.php");
                exit();
            } else {
                $_SESSION['error_message'] = "Error: " . $stmt->error;
                header("Location: donate.php"); // Redirect back on DB insert error
                exit();
            }
            $stmt->close();
        }
    }
}

// Only after all potential redirects, include header and display form
$user_id = $_SESSION['user_id']; // Re-fetch or keep user_id if needed below
$pageTitle = "Donate Food - Sharebite";
include 'includes/header.php'; // This is now called *after* all redirects.

$categories = [];
$stmt_cat = $conn->prepare("SELECT id, name FROM categories ORDER BY name ASC");
$stmt_cat->execute();
$result_cat = $stmt_cat->get_result();
while ($row_cat = $result_cat->fetch_assoc()) {
    $categories[] = $row_cat;
}
$stmt_cat->close();
?>

<section class="hero-background-inner-page text-white py-16 px-8 text-center">
    <div class="relative z-10 max-w-3xl mx-auto">
        <h1 class="text-5xl md:text-6xl font-extrabold mb-4 leading-tight">
            Offer a Food Donation
        </h1>
        <p class="text-xl md:text-2xl opacity-90">
            Help reduce waste and feed your community by listing your surplus food.
        </p>
    </div>
</section>

<main class="flex-grow container mx-auto p-8">
    <div class="form-card bg-white p-8 rounded-xl shadow-lg w-full max-w-2xl mx-auto text-left text-gray-800">
        <h2 class="text-4xl font-extrabold text-gray-800 mb-8 text-center">New Donation Form</h2>

        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="bg-emerald-100 border-l-4 border-emerald-500 text-emerald-700 p-4 mb-6 rounded-md" role="alert">
                <p><?php echo htmlspecialchars($_SESSION['success_message']); ?></p>
            </div>
            <?php unset($_SESSION['success_message']); ?>
        <?php endif; ?>
        <?php if (isset($_SESSION['error_message'])): ?>
            <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6 rounded-md" role="alert">
                <p><?php echo htmlspecialchars($_SESSION['error_message']); ?></p>
            </div>
            <?php unset($_SESSION['error_message']); ?>
        <?php endif; ?>

        <form action="donate.php" method="POST" enctype="multipart/form-data" class="space-y-6">
            <div>
                <label for="food_item" class="block text-gray-700 text-lg font-semibold mb-2">Food Item Name <span class="text-red-500">*</span></label>
                <input type="text" id="food_item" name="food_item" placeholder="e.g., Fresh Apples, Loaf of Bread" required
                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 text-lg">
            </div>

            <div>
                <label for="category_id" class="block text-gray-700 text-lg font-semibold mb-2">Category <span class="text-red-500">*</span></label>
                <select id="category_id" name="category_id" required
                        class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 text-lg bg-white">
                    <option value="">Select a Category</option>
                    <?php foreach ($categories as $cat): ?>
                        <option value="<?php echo htmlspecialchars($cat['id']); ?>"><?php echo htmlspecialchars($cat['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div>
                <label for="quantity" class="block text-gray-700 text-lg font-semibold mb-2">Quantity / Amount <span class="text-red-500">*</span></label>
                <input type="text" id="quantity" name="quantity" placeholder="e.g., 5 lbs, 10 pieces, 2 gallons" required
                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 text-lg">
            </div>

            <div>
                <label for="pickup_location" class="block text-gray-700 text-lg font-semibold mb-2">Pickup Location <span class="text-red-500">*</span></label>
                <input type="text" id="pickup_location" name="pickup_location" placeholder="e.g., Your Address or Public Place" required
                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 text-lg">
            </div>

            <div>
                <label for="description" class="block text-gray-700 text-lg font-semibold mb-2">Description (Optional)</label>
                <textarea id="description" name="description" rows="4" placeholder="Any additional details about the food, e.g., 'Homemade, organic', 'Frozen, needs defrosting'"
                          class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 text-lg"></textarea>
            </div>

            <div>
                <label for="allergens" class="block text-gray-700 text-lg font-semibold mb-2">Allergens (Optional)</label>
                <input type="text" id="allergens" name="allergens" placeholder="e.g., Contains nuts, dairy, gluten"
                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 text-lg">
            </div>

            <div>
                <label for="expiry_date" class="block text-gray-700 text-lg font-semibold mb-2">Expiry Date <span class="text-red-500">*</span></label>
                <input type="date" id="expiry_date" name="expiry_date" required
                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 text-lg">
            </div>

            <div>
                <label for="contact_info" class="block text-gray-700 text-lg font-semibold mb-2">Contact Information <span class="text-red-500">*</span></label>
                <input type="text" id="contact_info" name="contact_info" placeholder="e.g., your_email@example.com or Phone: 123-456-7890" required
                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 text-lg">
            </div>

            <div>
                <label for="image" class="block text-gray-700 text-lg font-semibold mb-2">Upload Image (Optional)</label>
                <input type="file" id="image" name="image" accept="image/*"
                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 text-lg bg-white">
            </div>

            <button type="submit" class="w-full bg-emerald-600 text-white py-3 px-6 rounded-full text-xl font-semibold hover:bg-emerald-700 transition duration-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:ring-opacity-50">
                Submit Donation
            </button>
        </form>
    </div>
</main>

<?php include 'includes/footer.php'; ?>