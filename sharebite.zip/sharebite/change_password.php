<?php
session_start();
include 'includes/db.php';

if (!isset($_SESSION['user_id'])) {
    $_SESSION['error_message'] = "You must be logged in to change your password.";
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_SESSION['user_id'];
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_new_password = $_POST['confirm_new_password'];

    // Fetch current hashed password from DB
    $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $stmt->close();

    if (!$user || !password_verify($current_password, $user['password'])) {
        $_SESSION['error_message'] = "Current password is incorrect.";
        header("Location: profile.php");
        exit();
    }

    if ($new_password !== $confirm_new_password) {
        $_SESSION['error_message'] = "New passwords do not match.";
        header("Location: profile.php");
        exit();
    }

    if (strlen($new_password) < 8) {
        $_SESSION['error_message'] = "New password must be at least 8 characters long.";
        header("Location: profile.php");
        exit();
    }

    // Hash the new password
    $hashed_new_password = password_hash($new_password, PASSWORD_DEFAULT);

    // Update password in DB
    $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
    $stmt->bind_param("si", $hashed_new_password, $user_id);

    if ($stmt->execute()) {
        $_SESSION['success_message'] = "Password changed successfully!";
    } else {
        $_SESSION['error_message'] = "Error changing password: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
    header("Location: profile.php");
    exit();
} else {
    header("Location: profile.php");
    exit();
}
?>