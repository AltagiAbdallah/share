<?php
session_start(); // Start the session at the very beginning of the script

// Add this line for debugging to confirm the file version being executed
error_log("DEBUG: login.php - Running version 20250614-1");

// Include the database connection file
require_once 'includes/db.php'; //

$error_message = '';
$success_message = '';

// Check if the form has been submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get email and password from the form
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    // Validate inputs (basic validation)
    if (empty($email) || empty($password)) {
        $error_message = "Please enter both email and password.";
    } else {
        // Prepare and execute the SQL query to fetch the user by email
        // Using prepared statements prevents SQL injection
        $stmt = $conn->prepare("SELECT id, name, email, password, user_type FROM users WHERE email = ?");
        $stmt->bind_param("s", $email); // "s" indicates string type for email
        $stmt->execute();
        $result = $stmt->get_result();

        // Check if a user with that email exists
        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();

            // Verify the submitted password against the hashed password from the database
            // password_verify() is crucial for hashed passwords
            if (password_verify($password, $user['password'])) { //
                // Password is correct, set session variables for login
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['name'];
                $_SESSION['user_email'] = $user['email'];
                $_SESSION['user_type'] = $user['user_type']; //

                // Set a success message to display on the dashboard (optional)
                $_SESSION['success_message'] = "Welcome, " . htmlspecialchars($user['name']) . "!";

                // Redirect based on user type (donor or receiver)
                if ($user['user_type'] == 'donor') { //
                    header("Location: dashboard.php"); // Example donor dashboard
                } elseif ($user['user_type'] == 'receiver') { //
                    header("Location: dashboard.php"); // Example receiver dashboard
                } else {
                    // Default redirect for other user types or if type is not recognized
                    header("Location: dashboard.php");
                }
                exit(); // Always exit after a header redirect
            } else {
                // Incorrect password
                $error_message = "Invalid email or password.";
            }
        } else {
            // User not found
            $error_message = "Invalid email or password.";
        }

        $stmt->close(); // Close the prepared statement
    }
}

// Close the database connection (important for resource management)
if (isset($conn)) {
    $conn->close();
}

// Include header and footer for the HTML structure
$pageTitle = "Login - Sharebite"; // Set page title
include 'includes/header.php'; //
?>

<section class="hero-background-inner-page text-white py-16 px-8 text-center">
    <div class="relative z-10 max-w-3xl mx-auto">
        <h1 class="text-5xl md:text-6xl font-extrabold mb-4 leading-tight">
            Login to Your Account
        </h1>
        <p class="text-xl md:text-2xl opacity-90">
            Access your dashboard and manage your contributions or requests.
        </p>
    </div>
</section>

<main class="flex-grow container mx-auto p-8">
    <div class="bg-white p-8 rounded-lg shadow-xl content-card">
        <h2 class="text-4xl font-extrabold text-gray-800 mb-8 text-center">Login</h2>

        <?php if (!empty($error_message)): ?>
            <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6 rounded-md" role="alert">
                <p><?php echo htmlspecialchars($error_message); ?></p>
            </div>
        <?php endif; ?>
        <?php if (isset($_SESSION['error_message_login'])): // For errors passed from other pages, if any ?>
            <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6 rounded-md" role="alert">
                <p><?php echo htmlspecialchars($_SESSION['error_message_login']); ?></p>
            </div>
            <?php unset($_SESSION['error_message_login']); ?>
        <?php endif; ?>

        <form action="login.php" method="POST" class="max-w-md mx-auto space-y-6">
            <div>
                <label for="email" class="block text-gray-700 text-sm font-bold mb-2">Email:</label>
                <input type="email" id="email" name="email" required
                       class="shadow appearance-none border rounded w-full py-3 px-4 text-gray-700 leading-tight focus:outline-none focus:shadow-outline focus:border-emerald-500 transition duration-200">
            </div>
            <div>
                <label for="password" class="block text-gray-700 text-sm font-bold mb-2">Password:</label>
                <input type="password" id="password" name="password" required
                       class="shadow appearance-none border rounded w-full py-3 px-4 text-gray-700 leading-tight focus:outline-none focus:shadow-outline focus:border-emerald-500 transition duration-200">
            </div>
            <div class="flex items-center justify-between">
                <button type="submit"
                        class="bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3 px-6 rounded-full focus:outline-none focus:shadow-outline transition duration-200">
                    Login
                </button>
                <a href="register.php" class="inline-block align-baseline font-bold text-sm text-emerald-600 hover:text-emerald-800">
                    Don't have an account? Register
                </a>
            </div>
        </form>
    </div>
</main>

<?php include 'includes/footer.php'; //?>