<?php
session_start();
include 'includes/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] != 'donor') {
    $_SESSION['error_message'] = "You must be logged in as a donor to cancel donations.";
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$donation_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($donation_id <= 0) {
    $_SESSION['error_message'] = "Invalid donation ID.";
    header("Location: my_contributions.php");
    exit();
}

// Check if the donation belongs to the logged-in user and is still 'pending'
$stmt = $conn->prepare("SELECT id FROM donations WHERE id = ? AND user_id = ? AND status = 'pending'");
$stmt->bind_param("ii", $donation_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Donation exists and is pending, proceed to cancel
    $stmt_update = $conn->prepare("UPDATE donations SET status = 'cancelled' WHERE id = ?");
    $stmt_update->bind_param("i", $donation_id);

    if ($stmt_update->execute()) {
        // Also cancel any pending requests for this donation
        $stmt_requests = $conn->prepare("UPDATE requests SET status = 'declined' WHERE donation_id = ? AND status = 'pending'");
        $stmt_requests->bind_param("i", $donation_id);
        $stmt_requests->execute();
        $stmt_requests->close();

        $_SESSION['success_message'] = "Donation cancelled successfully.";
    } else {
        $_SESSION['error_message'] = "Error cancelling donation: " . $stmt_update->error;
    }
    $stmt_update->close();
} else {
    $_SESSION['error_message'] = "Donation not found, already cancelled, or you do not have permission.";
}

$stmt->close();
$conn->close();
header("Location: my_contributions.php");
exit();
?>